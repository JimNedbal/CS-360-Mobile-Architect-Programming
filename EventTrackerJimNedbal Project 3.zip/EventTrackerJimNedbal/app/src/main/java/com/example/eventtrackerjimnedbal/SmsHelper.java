package com.example.eventtrackerjimnedbal;

import android.content.Context;
import android.telephony.SmsManager;

public class SmsHelper {

    // Sends an SMS reminder to the specified phone number.
    public static void sendEventReminder(
            Context context,
            String phoneNumber,
            String eventName,
            String eventDate,
            String eventTime) {

        String message =
                "Event Tracker Reminder: " +
                        eventName +
                        " is scheduled for " +
                        eventDate +
                        " at " +
                        eventTime + ".";

        SmsManager smsManager = SmsManager.getDefault();

        smsManager.sendTextMessage(
                phoneNumber,
                null,
                message,
                null,
                null
        );
    }
}