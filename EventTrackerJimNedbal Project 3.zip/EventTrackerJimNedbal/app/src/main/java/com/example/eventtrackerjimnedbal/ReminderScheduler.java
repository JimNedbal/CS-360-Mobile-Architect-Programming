package com.example.eventtrackerjimnedbal;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ReminderScheduler {

    // Schedules an SMS reminder for one day before the event.
    public static void scheduleReminder(
            Context context,
            int eventId,
            String eventName,
            String eventDate,
            String eventTime) {

        try {
            // Convert the date and time into a Date.
            SimpleDateFormat dateFormat =
                    new SimpleDateFormat(
                            "MM/dd/yyyy h:mma",
                            Locale.US
                    );

            dateFormat.setLenient(false);

            String dateTimeString = eventDate + " " + eventTime;


            Date eventDateTime =
                    dateFormat.parse(dateTimeString);

            if (eventDateTime == null) {

                Toast.makeText(
                        context,
                        "Event date/time could not be read.",
                        Toast.LENGTH_LONG
                ).show();

                return;
            }

            // Schedule the reminder one day before the event.
            long reminderTime =
                    eventDateTime.getTime() - (24 * 60 * 60 * 1000);

            Intent intent =
                    new Intent(context, ReminderReceiver.class);

            intent.putExtra("eventId", eventId);
            intent.putExtra("eventName", eventName);
            intent.putExtra("eventDate", eventDate);
            intent.putExtra("eventTime", eventTime);

            PendingIntent pendingIntent =
                    PendingIntent.getBroadcast(
                            context,
                            eventId,
                            intent,
                            PendingIntent.FLAG_UPDATE_CURRENT |
                                    PendingIntent.FLAG_IMMUTABLE
                    );

            AlarmManager alarmManager =
                    (AlarmManager) context.getSystemService(
                            Context.ALARM_SERVICE
                    );

            if (alarmManager == null) {

                Toast.makeText(
                        context,
                        "AlarmManager is not available.",
                        Toast.LENGTH_LONG
                ).show();

                return;
            }

            // Check exact alarm permission on newer Android versions.
            if (android.os.Build.VERSION.SDK_INT >=
                    android.os.Build.VERSION_CODES.S) {

                if (!alarmManager.canScheduleExactAlarms()) {

                    Toast.makeText(
                            context,
                            "Exact alarm permission is NOT granted.",
                            Toast.LENGTH_LONG
                    ).show();

                    return;
                }
            }

            // Schedule the alarm.
            alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    reminderTime,
                    pendingIntent
            );


        } catch (ParseException e) {

            Toast.makeText(
                    context,
                    "Could not read the event date/time.",
                    Toast.LENGTH_LONG
            ).show();

            e.printStackTrace();
        }
    }
}
