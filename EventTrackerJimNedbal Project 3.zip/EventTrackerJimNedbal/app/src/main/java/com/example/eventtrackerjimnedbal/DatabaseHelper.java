package com.example.eventtrackerjimnedbal;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Database information
    private static final String DATABASE_NAME = "EventTracker.db";
    private static final int DATABASE_VERSION = 1;

    // Users table
    public static final String TABLE_USERS = "Users";
    public static final String COLUMN_USER_ID = "id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";

    // Events table
    public static final String TABLE_EVENTS = "Events";
    public static final String COLUMN_EVENT_ID = "id";
    public static final String COLUMN_EVENT_NAME = "eventName";
    public static final String COLUMN_EVENT_DATE = "eventDate";
    public static final String COLUMN_EVENT_TIME = "eventTime";
    public static final String COLUMN_LOCATION = "location";
    public static final String COLUMN_DESCRIPTION = "description";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // Create the Users table.
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " (" +
                COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_USERNAME + " TEXT UNIQUE, " +
                COLUMN_PASSWORD + " TEXT)";

        // Create the Events table.
        String createEventsTable = "CREATE TABLE " + TABLE_EVENTS + " (" +
                COLUMN_EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_EVENT_NAME + " TEXT, " +
                COLUMN_EVENT_DATE + " TEXT, " +
                COLUMN_EVENT_TIME + " TEXT, " +
                COLUMN_LOCATION + " TEXT, " +
                COLUMN_DESCRIPTION + " TEXT)";

        db.execSQL(createUsersTable);
        db.execSQL(createEventsTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Delete the old tables when the database version changes.
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENTS);

        // Re-create the database tables.
        onCreate(db);
    }
    // Adds a new user to the database.
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);

        return result != -1;
    }


    // Adds a new event to the database.
    public long addEvent(String eventName, String eventDate, String eventTime,
                         String location, String description) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_EVENT_NAME, eventName);
        values.put(COLUMN_EVENT_DATE, eventDate);
        values.put(COLUMN_EVENT_TIME, eventTime);
        values.put(COLUMN_LOCATION, location);
        values.put(COLUMN_DESCRIPTION, description);

        long result = db.insert(TABLE_EVENTS, null, values);

        return result;
    }

    // Retrieves all events from the database.
    public Cursor getAllEvents() {
        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery("SELECT * FROM " + TABLE_EVENTS, null);
    }

    public Cursor getEventById(int eventId) {
        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery(
                "SELECT * FROM " + TABLE_EVENTS +
                        " WHERE " + COLUMN_EVENT_ID + " = ?",
                new String[]{String.valueOf(eventId)}
        );
    }

    // Updates an existing event in the database.
    public boolean updateEvent(int eventId, String eventName, String eventDate,
                               String eventTime, String location, String description) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_EVENT_NAME, eventName);
        values.put(COLUMN_EVENT_DATE, eventDate);
        values.put(COLUMN_EVENT_TIME, eventTime);
        values.put(COLUMN_LOCATION, location);
        values.put(COLUMN_DESCRIPTION, description);

        int result = db.update(
                TABLE_EVENTS,
                values,
                COLUMN_EVENT_ID + " = ?",
                new String[]{String.valueOf(eventId)}
        );

        return result > 0;
    }

    // Deletes an event from the database.
    public boolean deleteEvent(int eventId) {

        SQLiteDatabase db = this.getWritableDatabase();

        int result = db.delete(
                TABLE_EVENTS,
                COLUMN_EVENT_ID + " = ?",
                new String[]{String.valueOf(eventId)}
        );

        return result > 0;
    }

    // Checks whether a username and password exist in the database.
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_USERS +
                        " WHERE " + COLUMN_USERNAME + " = ? AND " +
                        COLUMN_PASSWORD + " = ?",
                new String[]{username, password}
        );

        boolean userExists = cursor.getCount() > 0;

        cursor.close();

        return userExists;
    }
}