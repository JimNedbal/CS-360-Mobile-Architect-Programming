package com.example.eventtrackerjimnedbal;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class EventListActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private TableLayout eventTable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_list);

        // Connect the Java variables to the XML layout.
        Button buttonAddEvent = findViewById(R.id.buttonAddEvent);
        eventTable = findViewById(R.id.eventTable);

        Button buttonNotificationSettings =
                findViewById(R.id.buttonNotificationSettings);

        // Create the database helper.
        databaseHelper = new DatabaseHelper(this);

        // Open the Add Event screen when the button is pressed.
        buttonAddEvent.setOnClickListener(v -> {
            Intent intent = new Intent(EventListActivity.this, AddEventActivity.class);
            startActivity(intent);
        });

        // Open Notification Settings when the button is pressed.
        buttonNotificationSettings.setOnClickListener(v -> {
            Intent intent = new Intent(
                    EventListActivity.this,
                    NotificationSettingsActivity.class
            );
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Refresh the event list whenever this screen becomes visible.
        displayEvents();
    }

    // Reads all events from SQLite and displays them in the table.
    private void displayEvents() {

        // Remove old event rows while keeping the header row.
        while (eventTable.getChildCount() > 1) {
            eventTable.removeViewAt(1);
        }

        Cursor cursor = databaseHelper.getAllEvents();

        while (cursor.moveToNext()) {

            int eventId = cursor.getInt(
                    cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_ID));

            String eventName = cursor.getString(
                    cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_NAME));

            String eventDate = cursor.getString(
                    cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_DATE));

            String eventTime = cursor.getString(
                    cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_TIME));

            TableRow row = new TableRow(this);

            TextView nameText = createTableText(eventName);
            TextView dateText = createTableText(eventDate);
            TextView timeText = createTableText(eventTime);

// Open the event in edit mode when the event name is pressed.
            nameText.setOnClickListener(v -> {

                Cursor eventCursor = databaseHelper.getEventById(eventId);

                if (eventCursor.moveToFirst()) {

                    String location = eventCursor.getString(
                            eventCursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_LOCATION));

                    String description = eventCursor.getString(
                            eventCursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_DESCRIPTION));

                    Intent intent = new Intent(
                            EventListActivity.this,
                            AddEventActivity.class
                    );

                    intent.putExtra("eventId", eventId);
                    intent.putExtra("eventName", eventName);
                    intent.putExtra("eventDate", eventDate);
                    intent.putExtra("eventTime", eventTime);
                    intent.putExtra("eventLocation", location);
                    intent.putExtra("eventDescription", description);

                    eventCursor.close();

                    startActivity(intent);
                } else {
                    eventCursor.close();
                }
            });

            Button deleteButton = new Button(this);
            deleteButton.setText("X");
            deleteButton.setBackgroundTintList(
                    getResources().getColorStateList(R.color.event_light_teal)
            );
            deleteButton.setTextColor(
                    getResources().getColor(R.color.red_x)
            );

// Delete the event when the X button is pressed.
            deleteButton.setOnClickListener(v -> {
                databaseHelper.deleteEvent(eventId);
                displayEvents();
            });

            row.addView(nameText);
            row.addView(dateText);
            row.addView(timeText);
            row.addView(deleteButton);

            eventTable.addView(row);
        }

        cursor.close();
    }

    // Creates a TextView for an event table cell.
    private TextView createTableText(String text) {

        TextView textView = new TextView(this);

        textView.setText(text);
        textView.setPadding(8, 8, 8, 8);
        textView.setGravity(Gravity.CENTER_VERTICAL);

        return textView;
    }
}