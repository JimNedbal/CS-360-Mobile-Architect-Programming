package com.example.eventtrackerjimnedbal;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddEventActivity extends AppCompatActivity {

    private EditText editEventName;
    private EditText editEventDate;
    private EditText editEventTime;
    private EditText editLocation;
    private EditText editDescription;

    private DatabaseHelper databaseHelper;

    // Holds the ID of the event being edited.
    // A value of -1 means we are adding a new event.
    private int eventId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        // Connect Java variables to the fields in the XML layout.
        editEventName = findViewById(R.id.editEventName);
        editEventDate = findViewById(R.id.editEventDate);
        editEventTime = findViewById(R.id.editEventTime);
        editLocation = findViewById(R.id.editLocation);
        editDescription = findViewById(R.id.editDescription);

        Button buttonSaveEvent = findViewById(R.id.buttonSaveEvent);
        Button buttonCancel = findViewById(R.id.buttonCancel);

        // Create the database helper.
        databaseHelper = new DatabaseHelper(this);

        // Check whether an existing event was selected.
        if (getIntent().hasExtra("eventId")) {

            eventId = getIntent().getIntExtra("eventId", -1);

            // Load the existing event information into the form.
            editEventName.setText(getIntent().getStringExtra("eventName"));
            editEventDate.setText(getIntent().getStringExtra("eventDate"));
            editEventTime.setText(getIntent().getStringExtra("eventTime"));
            editLocation.setText(getIntent().getStringExtra("eventLocation"));
            editDescription.setText(getIntent().getStringExtra("eventDescription"));
        }

        // Save the event when the button is pressed.
        buttonSaveEvent.setOnClickListener(v -> saveEvent());

        // Return to the previous screen when Cancel is pressed.
        buttonCancel.setOnClickListener(v -> finish());
    }

    // Adds a new event or updates an existing event.
    private void saveEvent() {

        String eventName = editEventName.getText().toString().trim();
        String eventDate = editEventDate.getText().toString().trim();
        String eventTime = editEventTime.getText().toString().trim();
        String location = editLocation.getText().toString().trim();
        String description = editDescription.getText().toString().trim();

        // Event name, date, and time are required.
        if (eventName.isEmpty() || eventDate.isEmpty() || eventTime.isEmpty()) {
            Toast.makeText(this,
                    "Please enter the event name, date, and time.",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        boolean success;

        // Update an existing event if an event ID was provided.
        if (eventId != -1) {

            success = databaseHelper.updateEvent(
                    eventId,
                    eventName,
                    eventDate,
                    eventTime,
                    location,
                    description
            );

            if (success) {
                Toast.makeText(this,
                        "Event updated successfully.",
                        Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this,
                        "Unable to update the event.",
                        Toast.LENGTH_SHORT).show();
                return;
            }

        } else {

            // Otherwise, create a new event.
            eventId = (int) databaseHelper.addEvent(
                    eventName,
                    eventDate,
                    eventTime,
                    location,
                    description
            );

            success = eventId != -1;

            if (success) {

                // Schedule an SMS reminder for the new event.
                ReminderScheduler.scheduleReminder(
                        this,
                        eventId,
                        eventName,
                        eventDate,
                        eventTime
                );

                Toast.makeText(this,
                        "Event saved successfully.",
                        Toast.LENGTH_SHORT).show();

            } else {
                Toast.makeText(this,
                        "Unable to save the event.",
                        Toast.LENGTH_SHORT).show();
                return;
            }
        }

        // Return to the event list.
        finish();
    }
}