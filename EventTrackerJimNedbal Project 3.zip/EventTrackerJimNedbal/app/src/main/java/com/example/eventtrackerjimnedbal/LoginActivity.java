package com.example.eventtrackerjimnedbal;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText editUsername;
    private EditText editPassword;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Create the notification channel when the app starts.
        NotificationHelper.createNotificationChannel(this);

        // Connect Java variables to the login fields in the XML layout.
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);

        Button buttonLogin = findViewById(R.id.buttonLogin);
        Button buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        // Create the database helper.
        databaseHelper = new DatabaseHelper(this);

        // Check the user's credentials when Login is pressed.
        buttonLogin.setOnClickListener(v -> loginUser());

        // Create a new account when Create Account is pressed.
        buttonCreateAccount.setOnClickListener(v -> createAccount());
    }

    // Checks the username and password against the database.
    private void loginUser() {

        String username = editUsername.getText().toString().trim();
        String password = editPassword.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this,
                    "Please enter a username and password.",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        if (databaseHelper.checkUser(username, password)) {

            Toast.makeText(this,
                    "Login successful.",
                    Toast.LENGTH_SHORT).show();

            // Open the event screen after a successful login.
            Intent intent = new Intent(LoginActivity.this, EventListActivity.class);
            startActivity(intent);

            finish();

        } else {
            Toast.makeText(this,
                    "Invalid username or password.",
                    Toast.LENGTH_SHORT).show();
        }
    }

    // Creates a new user account and saves it to the database.
    private void createAccount() {

        String username = editUsername.getText().toString().trim();
        String password = editPassword.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this,
                    "Please enter a username and password.",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        boolean success = databaseHelper.addUser(username, password);

        if (success) {
            Toast.makeText(this,
                    "Account created successfully.",
                    Toast.LENGTH_SHORT).show();

            editUsername.setText("");
            editPassword.setText("");

        } else {
            Toast.makeText(this,
                    "Username already exists.",
                    Toast.LENGTH_SHORT).show();
        }
    }
}