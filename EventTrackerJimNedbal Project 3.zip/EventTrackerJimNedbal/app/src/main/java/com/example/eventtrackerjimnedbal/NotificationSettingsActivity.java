package com.example.eventtrackerjimnedbal;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.EditText;


import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class NotificationSettingsActivity extends AppCompatActivity {

    private CheckBox checkEnableNotifications;
    private TextView textPermissionStatus;
    private android.content.SharedPreferences preferences;
    private EditText editPhoneNumber;


    // Handles the result of the SMS permission request.
    private final ActivityResultLauncher<String> requestSmsPermission =
            registerForActivityResult(
                    new ActivityResultContracts.RequestPermission(),
                    isGranted -> {

                        if (isGranted) {
                            textPermissionStatus.setText("SMS Permission: Granted");

                            preferences.edit()
                                    .putBoolean("smsNotificationsEnabled", true)
                                    .apply();

                            Toast.makeText(this,
                                    "SMS notifications are enabled.",
                                    Toast.LENGTH_SHORT).show();

                        } else {
                            textPermissionStatus.setText("SMS Permission: Not Granted");

                            checkEnableNotifications.setChecked(false);

                            Toast.makeText(this,
                                    "SMS permission was denied. The app will continue without SMS notifications.",
                                    Toast.LENGTH_LONG).show();
                        }
                    }
            );

    // Handles the result of the notification permission request.
    private final ActivityResultLauncher<String> requestNotificationPermission =
            registerForActivityResult(
                    new ActivityResultContracts.RequestPermission(),
                    isGranted -> {

                        if (isGranted) {

                            Toast.makeText(this,
                                    "App notifications are enabled.",
                                    Toast.LENGTH_SHORT).show();

                        } else {

                            Toast.makeText(this,
                                    "App notifications were denied. The app will continue to work normally.",
                                    Toast.LENGTH_LONG).show();
                        }
                    }
            );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification_settings);

        preferences = getSharedPreferences("EventTrackerSettings", MODE_PRIVATE);

        // Connect Java variables to the XML controls.
        editPhoneNumber = findViewById(R.id.editPhoneNumber);

        checkEnableNotifications =
                findViewById(R.id.checkEnableNotifications);

        textPermissionStatus =
                findViewById(R.id.textPermissionStatus);

        // Load the saved phone number.
        String savedPhoneNumber =
                preferences.getString("phoneNumber", "");

        editPhoneNumber.setText(savedPhoneNumber);

        boolean notificationsEnabled =
                preferences.getBoolean("smsNotificationsEnabled", false);

        checkEnableNotifications.setChecked(notificationsEnabled);

        Button buttonRequestPermission =
                findViewById(R.id.buttonRequestPermission);

        // FOR TESTING ---------------------------
        Button buttonTestSms =
                findViewById(R.id.buttonTestSms);

        // Request SMS permission when the user presses the button.
        buttonRequestPermission.setOnClickListener(v -> requestSmsPermission());

        // Sends a test SMS using the saved phone number. --------------
        buttonTestSms.setOnClickListener(v -> {

            String phoneNumber =
                    preferences.getString("phoneNumber", "");

            if (!notificationsEnabled) {

                Toast.makeText(this,
                        "Please enable SMS notifications first.",
                        Toast.LENGTH_SHORT).show();

                return;
            }

            if (checkSelfPermission(Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {

                Toast.makeText(this,
                        "SMS permission has not been granted.",
                        Toast.LENGTH_SHORT).show();

                return;
            }

            if (phoneNumber.isEmpty()) {

                Toast.makeText(this,
                        "Please enter a phone number first.",
                        Toast.LENGTH_SHORT).show();

                return;
            }

            SmsHelper.sendEventReminder(
                    this,
                    phoneNumber,
                    "Test Event",
                    "08/15/2026",
                    "6:00 PM"
            );

            Toast.makeText(this,
                    "Test SMS sent.",
                    Toast.LENGTH_SHORT).show();
        });

        // Request permission when the user enables SMS notifications.
        checkEnableNotifications.setOnCheckedChangeListener((buttonView, isChecked) -> {

            if (isChecked) {

                requestSmsPermission();

            } else {

                preferences.edit()
                        .putBoolean("smsNotificationsEnabled", false)
                        .apply();
            }
        });

        // Display the current permission status.
        updatePermissionStatus();
    }

    @Override
    protected void onPause() {
        super.onPause();

        // Save the phone number so it remains available for SMS reminders.
        preferences.edit()
                .putString(
                        "phoneNumber",
                        editPhoneNumber.getText().toString().trim()
                )
                .apply();
    }

    // Requests permission to send SMS messages.
    private void requestSmsPermission() {

        if (checkSelfPermission(Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {

            textPermissionStatus.setText("SMS Permission: Granted");

            preferences.edit()
                    .putBoolean("smsNotificationsEnabled", true)
                    .apply();

            Toast.makeText(this,
                    "SMS permission is already granted.",
                    Toast.LENGTH_SHORT).show();

        } else {
            requestSmsPermission.launch(Manifest.permission.SEND_SMS);
        }
    }

    // Updates the status text when the screen opens.
    private void updatePermissionStatus() {

        if (checkSelfPermission(Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {

            textPermissionStatus.setText("SMS Permission: Granted");

        } else {

            textPermissionStatus.setText("SMS Permission: Not Granted");
        }
    }

}