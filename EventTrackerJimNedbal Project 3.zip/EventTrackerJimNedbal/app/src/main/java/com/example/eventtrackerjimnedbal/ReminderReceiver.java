package com.example.eventtrackerjimnedbal;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.SharedPreferences;
import android.widget.Toast;

public class ReminderReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

        // Get the event information from the scheduled reminder.
        String eventName = intent.getStringExtra("eventName");
        String eventDate = intent.getStringExtra("eventDate");
        String eventTime = intent.getStringExtra("eventTime");

        // Load the user's saved notification settings.
        SharedPreferences preferences =
                context.getSharedPreferences(
                        "EventTrackerSettings",
                        Context.MODE_PRIVATE
                );

        boolean notificationsEnabled =
                preferences.getBoolean(
                        "smsNotificationsEnabled",
                        false
                );

        String phoneNumber =
                preferences.getString("phoneNumber", "");

        // Make sure SMS notifications are enabled.
        if (!notificationsEnabled) {
            return;
        }

        // Make sure SMS permission has been granted.
        if (context.checkSelfPermission(Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        // Make sure a phone number has been saved.
        if (phoneNumber.isEmpty()) {
            return;
        }

        // Send the event reminder.
        SmsHelper.sendEventReminder(
                context,
                phoneNumber,
                eventName,
                eventDate,
                eventTime
        );
    }
}
